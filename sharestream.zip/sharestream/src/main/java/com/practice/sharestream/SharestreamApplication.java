package com.practice.sharestream;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SharestreamApplication {

	public static void main(String[] args) {
		SpringApplication.run(SharestreamApplication.class, args);
	}

}
